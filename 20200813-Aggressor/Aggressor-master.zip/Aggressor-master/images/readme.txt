ladon for CS images
